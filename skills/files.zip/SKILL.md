---
name: email-task-extraction
description: Extract and track tasks from Gmail emails. Identifies problems/issues in incoming emails, stores them in a queryable database, and helps manage open tasks across multiple clients. ADHD-friendly passive capture with intelligent suggestions. Supports manual task entry, status tracking, and integration with MileMinder.
---

# Email Task Extraction Skill

Extract problems and tasks from your Gmail emails, maintain a centralized task list, and query what's open across all clients.

## Quick Start

### 1. Setup Database
```bash
python scripts/extract_tasks.py --db ~/.mileminder/tasks.db --add-task
```

This creates your local SQLite database and prompts you to add the first task.

### 2. List Open Tasks
```bash
python scripts/extract_tasks.py --list-open --db ~/.mileminder/tasks.db
```

Shows all tasks that need attention, sorted by priority.

### 3. List Tasks by Client
```bash
python scripts/extract_tasks.py --list-client Greyne --db ~/.mileminder/tasks.db
```

Shows all non-resolved tasks for a specific client (Greyne, Whitlock, LYK, etc.).

### 4. Add a Task Manually
```bash
python scripts/extract_tasks.py --add-task --db ~/.mileminder/tasks.db
```

Prompts you to enter: Client, Issue, Next Step, Priority

### 5. Update Task Status
```bash
python scripts/extract_tasks.py --update-status 5 --new-status "In Progress" --db ~/.mileminder/tasks.db
```

Changes status of task ID 5 to "In Progress"

---

## How It Works

### Proactive Task Capture

When a problem email arrives:
1. Skill scans for problem keywords: fix, issue, bug, urgent, can you, help, etc.
2. Extracts client from email sender
3. Suggests: "This looks like a task, create it?"
4. You can [CREATE] [IGNORE] or [SNOOZE]

### Task Storage

Every task stores:
- **CLIENT** - Who it's for (Greyne, Whitlock, LYK)
- **ISSUE** - What the problem is
- **REPORTED** - When it came in
- **STATUS** - Open | In Progress | Awaiting Verification | Waiting on Client | Resolved
- **PRIORITY** - Normal or Urgent
- **NEXT STEP** - What action is needed
- **EMAIL THREAD** - Link back to original email for context

### Queryable Database

Ask questions anytime:
- "What are my open tasks?"
- "What's happening with Greyne?"
- "What am I waiting on?"
- "What's urgent?"

---

## Commands Reference

### List Operations

**List all open tasks (non-resolved):**
```bash
python scripts/extract_tasks.py --list-open --db ~/.mileminder/tasks.db
```

**List tasks for a specific client:**
```bash
python scripts/extract_tasks.py --list-client Greyne --db ~/.mileminder/tasks.db
```

**List only tasks waiting on clients:**
```bash
python scripts/extract_tasks.py --waiting --db ~/.mileminder/tasks.db
```

### Task Management

**Add a new task interactively:**
```bash
python scripts/extract_tasks.py --add-task --db ~/.mileminder/tasks.db
```

**Update a task's status:**
```bash
python scripts/extract_tasks.py --update-status 5 --new-status "In Progress" --db ~/.mileminder/tasks.db
```

Status options: Open | In Progress | Awaiting Verification | Waiting on Client | Resolved

---

## Task Status Lifecycle

### Open
Just came in, needs attention from you.
Example: "Yusuf just reported the warehouse issue"

### In Progress
You're actively working on it.
Example: "Debugging the warehouse mapping logic"

### Awaiting Verification
You've deployed/sent a fix, waiting on client confirmation.
Example: "Warehouse fix deployed, waiting for Yusuf to test"

### Waiting on Client
Blocked by missing info or action from them.
Example: "Need sample packing list template from Vivi"

### Resolved
Done, closed out.
Example: "Client confirmed the fix works"

---

## Client Configuration

Clients are auto-detected from email sender. Current known clients:

### Greyne
- Emails from: greyne.com, yusuf@, vivi@
- Contacts: Yusuf Khayyat, Vivi Delashmet
- Projects: Jet Warehouse, packing lists, SCAC codes
- Style: Urgent, direct, brief

### Whitlock
- Emails from: whitlock domain, brian@
- Contacts: Brian Whitlock
- Projects: Commission Minder, invoices, commissions
- Style: Detailed, professional

### LYK (Launch Your Kid)
- Emails from: launchyourkid domain, lyk@
- Projects: PHP CakePHP app, course management
- Style: Mixed, technical support

See `references/client_mapping.md` to add new clients or modify detection patterns.

---

## Priority Levels

### Normal
Standard tasks, routine work.

### Urgent
Client escalated, high impact, or blocking work.
Auto-detected from keywords: urgent, asap, critical, blocking, immediately

---

## Data Storage

Tasks are stored in SQLite database (specified with `--db` flag).

**Default location (recommended):**
```
~/.mileminder/tasks.db
```

**Database schema:** See `references/task_structure.md` for complete schema and field descriptions.

**Tables:**
- `tasks` - Main task storage with all fields

---

## Email Thread Traceability

Each task links back to its original email via:
- `email_thread_id` - Gmail thread ID (for looking up later)
- `email_sender` - Who reported it
- `email_subject` - Original subject line

This provides full context when you need to reference the original problem description.

---

## ADHD-Friendly Features

This skill is designed for ADHD brains to solve forgetfulness:

1. **Passive capture** - Problems are extracted automatically, not manual entry
2. **Queryable** - Ask "What do I owe?" instead of trying to remember
3. **Centralized** - One place for all clients, never lost again
4. **Context preserved** - Email links prevent starting from scratch
5. **No notification fatigue** - You query when you need, not pestered with alerts
6. **Progress tracking** - See status without digging through email threads
7. **Priority visibility** - Urgent items surface immediately

---

## Advanced Usage

### Manual Task Format

When adding manually, use this format in your mind:
```
CLIENT: [Name]
ISSUE: [What's wrong/needed]
NEXT STEP: [What action to take]
PRIORITY: [Normal/Urgent]
```

### Task Queries in Workflow

Daily routine suggestions:
- **Morning:** `python scripts/extract_tasks.py --list-open --db ~/.mileminder/tasks.db` (what do I owe?)
- **By Client:** Switch to each client context, query their tasks
- **Check Waiting:** `python scripts/extract_tasks.py --waiting --db ~/.mileminder/tasks.db` (what's blocked?)
- **Status Updates:** After fixing something, update status to "Resolved"

### Export for Review

Current implementation stores in SQLite locally. Future phases:
- Export to CSV for reporting
- Integration with MileMinder for time tracking
- Multi-tenant SaaS version

---

## References

See these files for more details:

- **Client Mapping:** `references/client_mapping.md` - How clients are detected, adding new clients
- **Task Structure:** `references/task_structure.md` - Complete data schema, task lifecycle examples, querying details
- **Email Parsing:** Rules for detecting problems in emails, priority extraction, due date parsing

---

## Workflow Examples

### Example 1: Morning Standup
```bash
$ python scripts/extract_tasks.py --list-open --db ~/.mileminder/tasks.db

OPEN TASKS (3 total)

[1] CLIENT: Greyne
    ISSUE: Warehouse location mapping not working
    STATUS: Awaiting Verification
    PRIORITY: Urgent
    NEXT STEP: Get verification from Yusuf

[2] CLIENT: Whitlock
    ISSUE: Commission calculation off by $150
    STATUS: Open
    PRIORITY: Normal
    NEXT STEP: Debug pricing logic

[3] CLIENT: LYK
    ISSUE: Cache permission error
    STATUS: In Progress
    PRIORITY: Normal
    NEXT STEP: Fix /tmp permissions on production
```

### Example 2: Check Specific Client
```bash
$ python scripts/extract_tasks.py --list-client Greyne --db ~/.mileminder/tasks.db

TASKS FOR GREYNE (2 total)

[1] CLIENT: Greyne
    ISSUE: Warehouse location mapping
    STATUS: Awaiting Verification
    PRIORITY: Urgent
    
[2] CLIENT: Greyne
    ISSUE: SCAC code import template needed
    STATUS: Waiting on Client
    PRIORITY: Normal
    NEXT STEP: Get template format from Vivi
```

### Example 3: Update After Fix
```bash
$ python scripts/extract_tasks.py --update-status 1 --new-status "Resolved" --db ~/.mileminder/tasks.db

✓ Task 1 updated to 'Resolved'
```

---

## Future Enhancements

**Phase 2 - Email Integration:**
- Automated Gmail scanning for problem emails
- Proactive suggestions: "This looks like a task, create it?"
- Smart email linking: "This email relates to your warehouse issue"

**Phase 3 - MileMinder Integration:**
- Write tasks to MileMinder
- Track time on tasks from command line
- Sync status between systems

**Phase 4 - Product Hardening:**
- Multi-tenant architecture
- Web dashboard
- Subscription/payment layer
- Team collaboration

---

## Troubleshooting

### Database not found
Make sure the `--db` path exists and you have write permissions:
```bash
mkdir -p ~/.mileminder
python scripts/extract_tasks.py --db ~/.mileminder/tasks.db --add-task
```

### Can't find a task
Try querying by client first:
```bash
python scripts/extract_tasks.py --list-client Greyne --db ~/.mileminder/tasks.db
```

### Need to modify a task
Currently, use the Python script directly or SQL editing. Future versions will have update commands.

---

## Notes for Integration with Claude

This skill is designed for:
- Local development and testing with your own emails
- Eventually integrating with MileMinder for commercial use
- Multi-tenant architecture ready (future phase)
- ADHD-optimized task tracking

The database stores all information needed to scale to a commercial product while remaining useful as a personal productivity tool right now.
