# Email Task Extraction - Quick Reference

**Database location:** `~/.mileminder/tasks.db`

---

## Most Common Commands

### 1. What are my open tasks?
```bash
python /path/to/email-task-extraction-skill/scripts/extract_tasks.py --list-open --db ~/.mileminder/tasks.db
```

### 2. What's happening with [Client]?
```bash
python /path/to/email-task-extraction-skill/scripts/extract_tasks.py --list-client Greyne --db ~/.mileminder/tasks.db
```

### 3. What am I waiting on?
```bash
python /path/to/email-task-extraction-skill/scripts/extract_tasks.py --waiting --db ~/.mileminder/tasks.db
```

### 4. Add a new task
```bash
python /path/to/email-task-extraction-skill/scripts/extract_tasks.py --add-task --db ~/.mileminder/tasks.db
```

### 5. Mark task as done
```bash
python /path/to/email-task-extraction-skill/scripts/extract_tasks.py --update-status 1 --new-status "Resolved" --db ~/.mileminder/tasks.db
```

---

## Task Status Options

- `Open` - Just came in
- `In Progress` - You're working on it
- `Awaiting Verification` - Deployed, waiting on client confirmation
- `Waiting on Client` - Blocked, need their action/info
- `Resolved` - Done

---

## Known Clients

- **Greyne** - Yusuf, Vivi (warehouse, packing lists)
- **Whitlock** - Brian (commission, invoicing)
- **LYK** - Support (PHP app, course management)

---

## Alias Setup (Optional, saves typing)

Add to your `~/.bashrc` or `~/.zshrc`:

```bash
alias tasks-open="python /path/to/email-task-extraction-skill/scripts/extract_tasks.py --list-open --db ~/.mileminder/tasks.db"

alias tasks-greyne="python /path/to/email-task-extraction-skill/scripts/extract_tasks.py --list-client Greyne --db ~/.mileminder/tasks.db"

alias tasks-waiting="python /path/to/email-task-extraction-skill/scripts/extract_tasks.py --waiting --db ~/.mileminder/tasks.db"

alias tasks-add="python /path/to/email-task-extraction-skill/scripts/extract_tasks.py --add-task --db ~/.mileminder/tasks.db"
```

Then:
```bash
tasks-open          # See all open tasks
tasks-greyne        # See Greyne's tasks
tasks-waiting       # See what you're waiting on
tasks-add           # Add new task
```

---

## Daily Workflow

### Morning (5 min)
```bash
tasks-open          # What do I owe?
```

### Switch to Client
```bash
tasks-greyne        # What does Greyne need?
tasks-waiting       # What am I waiting on from them?
```

### After Fixing Something
```bash
# Update task status
python /path/to/email-task-extraction-skill/scripts/extract_tasks.py --update-status 1 --new-status "In Progress" --db ~/.mileminder/tasks.db

# Or to Resolved when done
python /path/to/email-task-extraction-skill/scripts/extract_tasks.py --update-status 1 --new-status "Resolved" --db ~/.mileminder/tasks.db
```

---

## Example Flow

```
$ tasks-open
OPEN TASKS (3 total)

[1] Greyne - Warehouse mapping issue (Awaiting Verification)
[2] Whitlock - Commission calculation (Open)
[3] LYK - Cache error (In Progress)

$ tasks-greyne
TASKS FOR GREYNE (2 total)

[1] Warehouse mapping - Awaiting Verification

$ tasks-waiting
WAITING ON CLIENT (1 total)

[1] Greyne - SCAC template needed
```

---

## Notes

- **No Gmail integration yet** - Phase 2 feature
- **Local SQLite only** - Syncs to MileMinder later
- **All client context in email links** - Check EMAIL_THREAD for full details
- **ADHD-friendly** - Query when you need, no alerts

---

**See full documentation:** `email-task-extraction-skill/SKILL.md`
